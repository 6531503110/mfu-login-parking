<template>
  <button type="submit" class="a-submitButton">
    <slot></slot>
  </button>
</template>

<style lang="scss" scoped>
@import "@/scss/components/buttons/_submitButton.scss";
</style>
